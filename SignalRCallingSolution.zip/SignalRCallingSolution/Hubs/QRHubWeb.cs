﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRCallingSolution.Hubs
{
    public class QRHubWeb : Hub
    {
        public Task AllowLogin(QR qr)
        {

            Groups.AddToGroupAsync(Context.ConnectionId, qr.QRId);
            Console.WriteLine("Receive token"+ qr.QRId);
            Console.WriteLine(qr);
            return Clients.Group(qr.QRId).SendAsync("ReceiveToken", qr);

        }
        public Task Connect(string qrId)
        {
            Console.WriteLine("Connect " + qrId);
            Groups.AddToGroupAsync(Context.ConnectionId, qrId);
            return Clients.Group(qrId).SendAsync("Connected","Success");

        } 
        public Task isLogin(string qrId,bool check)
        {
            Console.WriteLine("Connect " + qrId);
            Groups.AddToGroupAsync(Context.ConnectionId, qrId);
            return Clients.Group(qrId).SendAsync("isLogin",check);

        }
    }
    public class QR { 
        public string Token { get; set; }
        public string QRId { get; set; }
        public string QRUserName { get; set; }
        public string QRPassword { get; set; }

    }
}
