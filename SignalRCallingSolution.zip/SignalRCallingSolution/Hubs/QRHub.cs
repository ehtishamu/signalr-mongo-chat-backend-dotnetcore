﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace SignalRCallingSolution.Hubs
{
    public class QRHub:Hub
    {
        public Task Connection(string group,string qr)
        {

            Groups.AddToGroupAsync(Context.ConnectionId, group);
            if (qr == null) {
                return Clients.Client(Context.ConnectionId).SendAsync("Connection", "Success" );
            }
            return Clients.Group(group).SendAsync("ReceiveQR", qr);

        }
        public Task Connected(string group, string token)
        {
            return Clients.Group(group).SendAsync("Connected", token);

        }
        public Task AllowLogin(QR qr)
        {

            Groups.AddToGroupAsync(Context.ConnectionId, qr.QRId);
            Console.WriteLine("Receive token" + qr.QRId);
            Console.WriteLine(qr);
            return Clients.Group(qr.QRId).SendAsync("ReceiveToken", qr);

        }
        public Task Connect(string qrId)
        {
            Console.WriteLine("Connect " + qrId);
            Groups.AddToGroupAsync(Context.ConnectionId, qrId);
            return Clients.Group(qrId).SendAsync("Connected", "Success");

        }
        public Task isLogin(string qrId, bool check)
        {
            Console.WriteLine("Connect " + qrId);
            Groups.AddToGroupAsync(Context.ConnectionId, qrId);
            return Clients.Group(qrId).SendAsync("isLogin", check);

        }
    }
}
