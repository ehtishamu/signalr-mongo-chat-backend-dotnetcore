﻿using Microsoft.AspNetCore.Mvc;
using SignalRMongoChat.Interface;
using SignalRMongoChat.Model;
using System.Collections.Generic;

namespace SignalRCallingSolution.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CallLogController : ControllerBase
    {
        private readonly ICallLogService _service;
        public CallLogController(ICallLogService Service)
        {
            _service = Service;

        }
        [HttpGet]
        public ActionResult<List<CallLog>> GetCallLogsByAppointment(string appointmentId) =>
         _service.GetCallLogsByAppointment(appointmentId);
        [Route("today")]
        [HttpGet]
        public ActionResult<List<CallLog>> GetTodayCallLogs() =>
         _service.GetTodayCallLogs();

        
    }
}
