﻿
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;
using SignalRMongoChat.Interface;
using SignalRMongoChat.Model;


namespace SignalRMongoChat.Hubs
{

    public class CallLogHub : Hub
    {

        private readonly ICallLogService _service;
        public CallLogHub(ICallLogService Service)
        {
            _service = Service;

        }

        public Task JoinRoom(string query)
        {
            byte[] data = System.Convert.FromBase64String(query);
            query = System.Text.ASCIIEncoding.ASCII.GetString(data);
            CallLog callLog=Newtonsoft.Json.JsonConvert.DeserializeObject<CallLog>(query);
            callLog.ConnectionId = Context.ConnectionId;
            Groups.AddToGroupAsync(Context.ConnectionId, callLog.AppointmentId);
            CallLog res=_service.InsertCallLog(callLog);
            return Clients.Client(Context.ConnectionId).SendAsync("CallLogs", res);

        }
        public Task LeaveRoom(CallLog callLog)
        {

            callLog.ConnectionId = Context.ConnectionId;
            Groups.RemoveFromGroupAsync(Context.ConnectionId, callLog.AppointmentId);
            CallLog res=_service.UpdateCallLog(callLog);
            return Clients.Client(Context.ConnectionId).SendAsync("CallLogs", "Updated");

        }
        public override Task OnDisconnectedAsync(Exception exception)
        {
            CallLog callLog = new CallLog();
            callLog.ConnectionId = Context.ConnectionId;
            _service.AutoUpdateCallLog(callLog);
            return Clients.Client(Context.ConnectionId).SendAsync("CallLogs", "Updated");
        }     

    }

}
