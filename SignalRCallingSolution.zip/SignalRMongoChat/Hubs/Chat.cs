﻿
using System;
using System.Collections.Generic;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;
using SignalRMongoChat.Model;
using SignalRMongoChat.Service;

namespace SignalRMongoChat.Hubs
{

    public class Chat : Hub
    {

        private readonly MongoService _messageService;
        public Chat(MongoService MessageService)
        {
            _messageService = MessageService;

        }

        public async Task JoinRoom(string group) {

            string jsonString = JsonSerializer.Serialize(group);
            var messages= _messageService.GetGroupMessages(group);
            Groups.AddToGroupAsync(Context.ConnectionId, group);
            // Clients.Client(Context.ConnectionId).SendAsync("AllMessage", messages);

        }
        public Task SendMessage( Message message)
        {
            _messageService.InsertMessages(message);
            string jsonString = JsonSerializer.Serialize(message);
            return Clients.Group(message.group).SendAsync("OnMessage", message);
        }
        public  Task UpdateMessage(Message message) {
             _messageService.UpdateMessage(message);
            var messages = _messageService.GetGroupMessages(message.group);
            return Clients.Group(message.group).SendAsync("AllMessage", messages);
        }
        public  async Task UpdateAllMessage(List<Message> messageList) {
            if (messageList != null)
            {
                foreach (Message message in messageList)
                {
                    _messageService.UpdateMessage(message);
                }

                var messages = _messageService.GetGroupMessages(messageList[0].group);
                await Clients.Group(messageList[0].group).SendAsync("AllMessage", messages);
            }
            await Clients.All.SendAsync("Error", "Some thing went wrong");
        }        
        public Task JoinRoomSpecific(string group,string from,string to)
        {

            string jsonString = JsonSerializer.Serialize(group);
            var messages = _messageService.GetSpecificMessages(group,from,to);
            Groups.AddToGroupAsync(Context.ConnectionId, group);
            return Clients.Client(Context.ConnectionId).SendAsync("AllMessage", messages);

        }
        public Task UpdateMessageSpecific(Message message)
        {
            _messageService.UpdateMessage(message);
            var messages = _messageService.GetSpecificMessages(message.group,message.from,message.to);
            return Clients.Group(message.group).SendAsync("AllMessage", messages);
        }
        public  async Task UpdateAllMessageSpecific(List<Message> messageList) {
            if (messageList != null)
            {
                foreach (Message message in messageList)
                {
                    _messageService.UpdateMessage(message);
                }

                var messages = _messageService.GetSpecificMessages(messageList[0].group,messageList[0].from,messageList[0].to);
                await Clients.Group(messageList[0].group).SendAsync("AllMessage", messages);
            }
            await Clients.All.SendAsync("Error", "Some thing went wrong");
        }
        public Task Online(string group,string name)
        {
            UserDetail u = new UserDetail();
            u.id = Context.ConnectionId;
            u.name = name;
            return Clients.OthersInGroup(group).SendAsync("Online", u);
        }
        public Task Offline(string group, string name)
        {
            UserDetail u = new UserDetail();
            u.id = Context.ConnectionId;
            u.name = name;
            return Clients.OthersInGroup(group).SendAsync("Offline", u);
        }
        public override Task OnDisconnectedAsync(Exception exception) {
            return Clients.All.SendAsync("Disconnected", Context.ConnectionId);
        }
        public override Task OnConnectedAsync()
        {
            string jsonString = JsonSerializer.Serialize(Context.ConnectionId);
            //InterServiceLog.WriteLog("Room Connected", jsonString);
            return Clients.All.SendAsync("Connected", Context.ConnectionId);
        }






    }

    public class UserDetail { 
        public string id { set; get; }
        public string name { set; get; }
    }
}
