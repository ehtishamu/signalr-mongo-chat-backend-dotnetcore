﻿using MongoDB.Bson;
using MongoDB.Driver;
using SignalRMongoChat.Interface;
using SignalRMongoChat.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace SignalRMongoChat.Service
{
    public class CallLogService : ICallLogService
    {
        private readonly MongoService _mongoService;
        public CallLogService(MongoService mongoService)
        {
            _mongoService = mongoService;

        }

        public List<CallLog> GetCallLogsByAppointment(string AppointmentId)
        {
            return _mongoService.getCallLogsDb().Find(o => o.AppointmentId == AppointmentId).ToList();
        }
        public List<CallLog> GetTodayCallLogs()
        {
            
            return _mongoService.getCallLogsDb().Find(x=>x.Id!=null).ToList();
        }
        public CallLog InsertCallLog(CallLog obj)
        {
            obj.Id = null;
            obj.StartTime = DateTime.UtcNow;
            _mongoService.getCallLogsDb().InsertOne(obj);
            return obj;
        }
        public CallLog UpdateCallLog(CallLog obj)
        {
            CallLog call = _mongoService.getCallLogsDb().Find(x => x.ConnectionId == obj.ConnectionId).FirstOrDefault();
            if (call != null)
            {
                call.EndTime = DateTime.UtcNow;
                call.Duration = call.EndTime.Subtract(call.StartTime);
                call.IsAudioMuted = obj.IsAudioMuted;
                call.IsVideoHidden = obj.IsVideoHidden;
                _mongoService.getCallLogsDb().ReplaceOne(x => x.Id == call.Id, call);
            }
            return call;
        }
        public void AutoUpdateCallLog(CallLog obj)
        {
            CallLog callLog = _mongoService.getCallLogsDb().Find(x => x.ConnectionId == obj.ConnectionId).FirstOrDefault();
            callLog.EndTime = DateTime.UtcNow;
            callLog.Duration = callLog.EndTime.Subtract(callLog.StartTime);
            _mongoService.getCallLogsDb().ReplaceOne(obj => obj.Id == callLog.Id, callLog);
        }

        public List<CallLog> Get() =>
            _mongoService.getCallLogsDb().Find(obj => true).ToList();


    }
}
