﻿

namespace SignalRMongoChat.Service
{
    public class MongoDatabaseSettings : IMongoDatabaseSettings
    {
        public string CollectionName { get; set; }
        public string ConnectionString { get; set; }
        public string DatabaseName { get; set; }
        public string MessageCollection { get; set; }
        public string CallLogCollection { get; set; }
    }
}
