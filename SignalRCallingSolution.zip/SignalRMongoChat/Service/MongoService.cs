﻿
using MongoDB.Driver;
using SignalRMongoChat.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRMongoChat.Service
{
    public class MongoService
    {
        private readonly IMongoCollection<Message> _messages;
        private readonly IMongoCollection<CallLog> _callLogs;

        public MongoService(IMongoDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);

            _messages = database.GetCollection<Message>(settings.MessageCollection);
            _callLogs = database.GetCollection<CallLog>(settings.CallLogCollection);
        }
        public IMongoCollection<Message> getMessagesDb() {
            return _messages;
        }
        public IMongoCollection<CallLog> getCallLogsDb() {
            return _callLogs;
        }
        public List<Message> GetGroupMessages(string group)
        {
            return _messages.Find(message => message.group == group).ToList();
        }
        public List<Message> GetSpecificMessages(string group,string from,string to)
        {
            return _messages.Find(message => message.group == group && message.from ==from && message.to==to).ToList();
        }
        public Message InsertMessages(Message message)
        {
            message.Id = null;
            message.createdAt = DateTime.UtcNow;
            message.updatedAt = DateTime.UtcNow;
            _messages.InsertOne(message);
            return message;
        } 
        public void UpdateMessage(Message msg)
        {
            msg.updatedAt = DateTime.UtcNow;
            _messages.ReplaceOne(message => message.Id == msg.Id, msg);       
        }
        
        public List<Message> Get() =>
            _messages.Find(message => true).ToList();

    }
}
