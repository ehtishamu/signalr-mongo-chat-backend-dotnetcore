﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;


namespace SignalRMongoChat.Model
{
    public class CallLog
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }
        public string ConnectionId { get; set; }
        public string AppointmentId { get; set; }
        public string PracticeCode { get; set; }
        public string ProviderCode { get; set; }
        public string Perspective { get; set; }
        public string ParticipantName { get; set; }
        public string PatientName { get; set; }
        public string ProviderName { get; set; }
        public string ParentUrl { set; get; }
        public string DeviceInfo { set; get; }
        public string Logs { set; get; }
        public bool IsMobile { set; get; }
        public bool IsVideoHidden { set; get; }
        public bool IsAudioMuted { set; get; }
        public DateTime StartTime { set; get; }
        public DateTime EndTime { set; get; }
        public TimeSpan Duration { set; get; }
       
    }
}
