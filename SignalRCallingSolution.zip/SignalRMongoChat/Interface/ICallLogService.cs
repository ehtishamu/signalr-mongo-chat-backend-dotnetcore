﻿using SignalRMongoChat.Model;
using System;
using System.Collections.Generic;
using System.Text;

namespace SignalRMongoChat.Interface
{
    public interface ICallLogService
    {
        List<CallLog> GetCallLogsByAppointment(string AppointmentId);
        List<CallLog> GetTodayCallLogs();
        CallLog InsertCallLog(CallLog obj);
        CallLog UpdateCallLog(CallLog obj);
        void AutoUpdateCallLog(CallLog obj);
    }
}
