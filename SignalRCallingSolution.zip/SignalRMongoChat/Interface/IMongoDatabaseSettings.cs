﻿
namespace SignalRMongoChat.Service
{
    public interface IMongoDatabaseSettings
    {
        string CollectionName { get; set; }
        string ConnectionString { get; set; }
        string DatabaseName { get; set; }
        public string MessageCollection { get; set; }
        public string CallLogCollection { get; set; }
    }
}
