﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SignalRMongoChat.Interface
{
    public interface IMongoService
    {
    }
}
